#ifndef _BALL_H_
#define _BALL_H_

#include <EGL/egl.h>
#include <GLES/gl.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

#include "Box2D.h"

class Ball {
private:
  GLfloat pos_x;
  GLfloat pos_y;
  b2Body* ball;
  GLfloat health;
  int texture;
  
public:
  Ball() {
  }
  Ball(b2World *world) {

	pos_x = 300.0f;
	pos_y = 150.0f;
	// Define another box shape for our dynamic body.
	b2BodyDef bd;
	bd.type = b2_dynamicBody;
	bd.position.Set(pos_x, pos_y);
	bd.allowSleep = false;
	ball = world->CreateBody(&bd);

	b2CircleShape shape;
	shape.m_radius = 70.0f;

	ball->CreateFixture(&shape, 1.0f);

	health = 255.0f;
	
  }
  void setTexture(int tex);
  void draw();
  void draw_square(GLfloat vertex[4][2], GLfloat colors[3][4]);
  void drawTexture();
  GLfloat getHealth();
  void decreaseHealth(GLfloat h);
};

#endif
