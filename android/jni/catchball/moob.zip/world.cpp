#include "world.h"

b2World* World::getWorld() {
  return world;
}